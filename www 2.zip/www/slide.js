window.addEventListener("load", function () {

    var arrowl = document.querySelector("#arrow-l");
    var arrowr = document.querySelector("#arrow-r");
    var focus = document.querySelector(".focus");
    var focus2 = document.querySelector(".focus2");
    var ul = focus.querySelector('ul');
    var ol = focus2.querySelector("ol");
    var lis = ul.querySelectorAll("li");
    var focusWidth = focus.offsetWidth;

    focus.addEventListener("mouseenter", function () {
        arrowl.style.display = 'block';
        arrowr.style.display = 'block';
    });

    focus.addEventListener("mouseleave", function () {
        arrowl.style.display = 'none';
        arrowr.style.display = 'none';
    });

    for (var i = 0; i < ul.children.length; i++) {

        lis[i].setAttribute("index1", i);
        var li = document.createElement("li");
        ol.appendChild(li);
        li.setAttribute("index2", i);
        li.innerHTML = '<img src="" alt=""> </a> <div class = ""></div>';
    }

    var div2 = focus2.querySelectorAll("div");
    var img1 = focus.querySelectorAll("img");
    var img2 = focus2.querySelectorAll("img");
    var lis2 = focus2.querySelectorAll("li");
    var circle = 0;
    var picNum = 0;

    for (i = 0; i < ul.children.length; i++) { //把下面的小图片按照上面的大图片路径复制
        img2[i].src = img1[i].src;
    }

    for (i = 0; i < ul.children.length; i++) {  //给下面的小图片增加一个类名，点击的图片显示模糊
        div2[i].addEventListener("click", function () {
            for (i = 0; i < lis2.length; i++) {
                div2[i].className = "";
            }
            this.className = "overlay";
        });
    }

    div2[0].className = "overlay";

    for (i = 0; i < ul.children.length; i++) {
        lis2[i].addEventListener("click", function () {
            var index = this.getAttribute("index2");
            gotoslideshow(index);
        });
    }

    function gotoslideshow(num) {
        ul.style.transform = "translateX(-" + num * focusWidth + "px";
    }

    function gotocircle(circle) {
        for (var i = 0; i < ul.children.length; i++) {
            div2[i].className = "";
        }
        div2[circle].className = "overlay";
    }


    arrowr.addEventListener("click", function () {
        if (picNum == ul.children.length - 1) {
            picNum = 0;
            gotoslideshow(0);
            circle = 0;
            gotocircle(0);
            return;
        }
        picNum++;
        gotoslideshow(picNum);
        circle++;
        gotocircle(circle);
    });

    arrowl.addEventListener("click", () => {
        if (picNum == 0) {
            picNum = ul.children.length - 1;
            gotoslideshow(picNum);
            circle = ul.children.length - 1;
            gotocircle(circle);
            return;
        }
        picNum--;
        gotoslideshow(picNum);
        circle--;
        gotocircle(circle);
    });
});
